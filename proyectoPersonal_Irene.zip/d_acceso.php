<?php 
    $host = 'localhost';
    $bd = 'proyecto';
    $user = 'root';
    $pass = '';
?>